

export interface Product {
  id?: number;
  categoryId?: number;
  img: string;
  title: string;
  price: number;
  description: string;
}

